import sys
import os

print("Verifying project structure...")
required_files = [
    "src/main.py",
    "src/models.py",
    "src/database.py",
    "src/srs.py",
    "src/latin_logic.py",
    "src/styles.tcss",
    "src/screens/dashboard.py",
    "src/screens/vocabulary.py",
    "src/screens/declension.py",
    "src/screens/conjugation.py",
    "src/screens/analysis.py",
    "src/screens/reading.py",
    "data/vocabulary.csv",
    "requirements.txt"
]

missing = []
for f in required_files:
    if not os.path.exists(f):
        missing.append(f)

if missing:
    print(f"ERROR: Missing files: {missing}")
    sys.exit(1)

print("Verifying imports...")
try:
    from src.models import Word
    from src.database import init_db
    from src.latin_logic import LatinMorphology
    from src.srs import calculate_next_review
    print("Backend imports successful.")
except ImportError as e:
    print(f"ERROR: Import failed: {e}")
    sys.exit(1)

print("Verification successful! Lingua Latina Viva is ready.")
