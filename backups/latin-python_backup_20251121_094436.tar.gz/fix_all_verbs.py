"""
Script to fix ALL verb data in the database with proper conjugations and principal parts
"""
import sys
sys.path.append('.')

from database.connection import get_session
from database.models import Word
from sqlmodel import select

# Correct verb data based on standard Latin conjugations
correct_verbs = {
    "amo": {
        "principal_parts": "amo, amare, amavi, amatum",
        "conjugation": "1",
        "translation": "amar"
    },
    "moneo": {
        "principal_parts": "moneo, monere, monui, monitum",
        "conjugation": "2",
        "translation": "advertir"
    },
    "rego": {
        "principal_parts": "rego, regere, rexi, rectum",
        "conjugation": "3",
        "translation": "gobernar/dirigir"
    },
    "audio": {
        "principal_parts": "audio, audire, audivi, auditum",
        "conjugation": "4",
        "translation": "oír"
    }
}

with get_session() as session:
    for latin, data in correct_verbs.items():
        verb = session.exec(select(Word).where(Word.latin == latin)).first()
        if verb:
            verb.principal_parts = data["principal_parts"]
            verb.conjugation = data["conjugation"]
            if data.get("translation"):
                verb.translation = data["translation"]
            session.add(verb)
            print(f"✓ Fixed: {latin} ({data['conjugation']}ª conjugación)")
        else:
            # Create if doesn't exist
            new_verb = Word(
                latin=latin,
                translation=data["translation"],
                part_of_speech="verb",
                level=1,
                principal_parts=data["principal_parts"],
                conjugation=data["conjugation"]
            )
            session.add(new_verb)
            print(f"✓ Created: {latin} ({data['conjugation']}ª conjugación)")
    
    session.commit()
    print("\n✨ All verbs updated successfully!")
