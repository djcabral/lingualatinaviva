import sys
import os

# Add project root to path
sys.path.append(os.getcwd())

from utils.latin_logic import LatinMorphology

def test_syncretism():
    morphology = LatinMorphology()
    
    # Test normalization
    assert morphology.normalize_latin("puella") == "puella"
    assert morphology.normalize_latin("puellā") == "puella"
    assert morphology.normalize_latin("puerī") == "pueri"
    print("✅ Normalization logic passed.")

    # Test declension syncretism logic
    # Simulate what happens in Analysis.py
    word = "puella"
    declension = "1"
    gender = "f"
    genitive = "puellae"
    
    forms = morphology.decline_noun(word, declension, gender, genitive)
    
    # Let's say the system picked "puellā" (Ablative Singular)
    selected_form = forms["abl_sg"] # Should be "puellā"
    print(f"Selected form: {selected_form}")
    
    # User sees "puellā" (or "puella" if we displayed it without macrons, but currently we display with macrons)
    # The user's issue was: "acabo de identificar puella como nominativo singular femenino, pero el sistema me dice que estoy equivocado, que es ablativo singular femenino"
    # This implies the system showed "puella" (maybe?) or "puellā" and the user couldn't tell the difference or the system was too strict.
    
    # With my change:
    normalized_selected = morphology.normalize_latin(selected_form)
    
    all_valid_tags = [k for k, v in forms.items() if morphology.normalize_latin(v) == normalized_selected]
    
    print(f"All valid tags for '{selected_form}': {all_valid_tags}")
    
    # Check if both nom_sg (puella) and abl_sg (puellā) are in the valid tags list
    # nom_sg is "puella", abl_sg is "puellā". Normalized they are equal.
    
    assert "nom_sg" in all_valid_tags
    assert "abl_sg" in all_valid_tags
    
    print("✅ Syncretism logic passed: 'nom_sg' and 'abl_sg' are both considered valid for 'puellā' (normalized).")

if __name__ == "__main__":
    test_syncretism()
