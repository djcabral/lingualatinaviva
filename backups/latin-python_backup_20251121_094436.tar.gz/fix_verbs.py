"""
Script to fix verb data in the database
"""
import sys
sys.path.append('.')

from database.connection import get_session
from database.models import Word
from sqlmodel import select

with get_session() as session:
    # Fix moneo
    verb = session.exec(select(Word).where(Word.latin == 'moneo')).first()
    if verb:
        verb.principal_parts = "moneo, monere, monui, monitum"
        verb.conjugation = "2"
        session.add(verb)
        print(f"✓ Fixed: {verb.latin}")
    
    # Fix any other verbs with similar issues
    all_verbs = session.exec(select(Word).where(Word.part_of_speech == "verb")).all()
    for v in all_verbs:
        # Check if conjugation is not a number
        if v.conjugation and not v.conjugation.isdigit():
            print(f"⚠ Warning: {v.latin} has invalid conjugation: {v.conjugation}")
        
        # Check if principal_parts is missing commas
        if v.principal_parts and ',' not in v.principal_parts:
            print(f"⚠ Warning: {v.latin} has incomplete principal parts: {v.principal_parts}")
    
    session.commit()
    print("\nDatabase updated!")
