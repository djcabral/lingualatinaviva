import sys
import os
import csv
sys.path.append(os.path.join(os.getcwd(), "src"))

from sqlmodel import Session, select, delete
from database import engine
from models import Word

def reimport_vocabulary():
    csv_path = os.path.join("data", "vocabulary_es.csv")
    if not os.path.exists(csv_path):
        print(f"Error: {csv_path} not found.")
        return

    with Session(engine) as session:
        # Clear existing words
        print("Clearing existing vocabulary...")
        session.exec(delete(Word))
        session.commit()
        
        # Import new words
        print(f"Importing from {csv_path}...")
        count = 0
        with open(csv_path, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Clean latin word just in case
                latin_clean = ''.join([c for c in row['latin'] if not c.isdigit() and c != '_'])
                
                word = Word(
                    latin=latin_clean,
                    translation=row['translation'],
                    part_of_speech=row['part_of_speech'],
                    level=int(row['level']),
                    genitive=row.get('genitive'),
                    gender=row.get('gender'),
                    declension=row.get('declension'),
                    principal_parts=row.get('principal_parts'),
                    conjugation=row.get('conjugation')
                )
                session.add(word)
                count += 1
        
        session.commit()
        print(f"Successfully imported {count} words.")

if __name__ == "__main__":
    reimport_vocabulary()
