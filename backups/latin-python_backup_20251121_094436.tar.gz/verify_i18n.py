
from src.i18n import get_text

print(f"Dashboard (ES): {get_text('dashboard', 'es')}")
print(f"Dashboard (EN): {get_text('dashboard', 'en')}")
print(f"Dashboard (Default): {get_text('dashboard')}")

assert get_text('dashboard', 'es') == "Tablero"
assert get_text('dashboard', 'en') == "Dashboard"
print("i18n verification successful.")
