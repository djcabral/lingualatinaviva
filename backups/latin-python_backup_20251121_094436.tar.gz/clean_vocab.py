from sqlmodel import Session, select
from src.database import engine
from src.models import Word

def clean_vocabulary():
    with Session(engine) as session:
        words = session.exec(select(Word)).all()
        count = 0
        for word in words:
            original = word.latin
            # Remove digits and underscores
            cleaned = ''.join([c for c in original if not c.isdigit() and c != '_'])
            
            if original != cleaned:
                print(f"Cleaning: {original} -> {cleaned}")
                word.latin = cleaned
                session.add(word)
                count += 1
        
        session.commit()
        print(f"Cleaned {count} words.")

if __name__ == "__main__":
    clean_vocabulary()
