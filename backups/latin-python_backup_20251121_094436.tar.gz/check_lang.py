import sys
import os
sys.path.append(os.path.join(os.getcwd(), "src"))

from sqlmodel import Session, select
from database import engine
from models import Word

def check_vocab_language():
    with Session(engine) as session:
        words = session.exec(select(Word).limit(5)).all()
        for word in words:
            print(f"Latin: {word.latin}, Translation: {word.translation}")

if __name__ == "__main__":
    check_vocab_language()
